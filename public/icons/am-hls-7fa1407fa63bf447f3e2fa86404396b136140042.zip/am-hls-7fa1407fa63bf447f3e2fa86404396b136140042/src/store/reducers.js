import { combineReducers } from 'redux'

import test from './reducers/test'

export default combineReducers({
	test,
})
