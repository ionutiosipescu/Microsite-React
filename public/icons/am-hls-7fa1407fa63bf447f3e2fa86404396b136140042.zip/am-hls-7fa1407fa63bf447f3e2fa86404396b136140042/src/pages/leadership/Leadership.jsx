import React from "react";

const Leadership = () => {
  return <div>Leadership</div>;
};

export default Leadership;
