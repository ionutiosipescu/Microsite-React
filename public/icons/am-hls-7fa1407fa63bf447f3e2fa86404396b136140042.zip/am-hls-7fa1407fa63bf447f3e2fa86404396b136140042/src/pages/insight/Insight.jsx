import React from "react";

const Insight = () => {
  return <div>Insight</div>;
};

export default Insight;
