import React from "react";

const Expertise = () => {
  return <div>Expertise</div>;
};

export default Expertise;
