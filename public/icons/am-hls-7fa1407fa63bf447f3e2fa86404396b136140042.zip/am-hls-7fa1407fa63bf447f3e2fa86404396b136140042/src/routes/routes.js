import webRoutes from './routes/dashboard'

let routes = [...webRoutes]
export default routes
